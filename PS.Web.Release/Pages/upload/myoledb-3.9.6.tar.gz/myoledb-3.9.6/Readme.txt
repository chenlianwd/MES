-------------------------------------------------
OLE DB Provider for MySQL (MyOLEDB)                        Updated 2006/01/16

Read Me Notes
-------------------------------------------------

-------------------------------------------------
Copyright 2006, St. James Software (http://www.sjsoft.com)
Based on GPL release of Readme.txt by SWsoft Inc. (copyright 2000-2001)
  * SWSoft email address: oledb@sw-soft.com.
---------------------------------------------

Contents

1. General Information
2. System Requirements
3. Getting Started
4. Disclaimer


---------------------------------------------
1. General Information
---------------------------------------------

MySQL OLE DB Provider (MyOLEDB) v.3.9 is an OLE DB provider capable of
supplying OLE DB consumer with base functional access to the data stored in
MySQL database. In addition, provider supports schemas, commands and MySQL
(http://www.mysql.com) databases enumerator object.

Although we view this release as more stable than the v3.0 series, the
fact that this is not v4.0 is meant to show that this is a beta release.

-----------------------------------------------
2. System Requirements:
-----------------------------------------------

Operating System: Windows95/98, Windows ME, WinNT4 or Windows 2000
MySQL server should be available.
Microsoft Data Access Components 2.0
In order to use HTML help system Internet Explorer 4.01 or higher must be
installed.

------------------------------------------------
3. Getting Started
------------------------------------------------

Step 1. Download installation package, compile and install it on your WinNT, 
W2K or Win95/98/ME WORKSTATION.

Step 2. Find out the MySQL server  name and name of database you are going to
use. OLE DB / ADO connection parameters will be:

 Provider:    MySQLProv
 Data Source: SERVER=server_name;DB=database_name;UID=user_name;PWD=password;PORT=port_number

OR

 Provider:    MySQLProv
 Location:    server_name
 Data Source: database_name
 User:        user_name
 Password:    password

Default value 'localhost' (local computer) is used server_name is not present.
Empty strings are default values for database_name, user_name and password.
You may be not able to connect if you didn't specify the value.
Default value (3306) is used if port_number is omitted. Usually it's OK.

You may mix first and second ways to pass connection data, but it is not 
recommended; In that case, you have to pass a parameter only once.

Step 2a.
If whatever you're using has issues setting a custom port number (e.g. some 
ADO-driven programs), the driver also honours the MYSQL_TCP_PORT 
environment variable.  Setting this to your non-standard port means
you do not have to pass the port number in.  This step is unnecessary
if you're using the standard port number of 3306.

Step 3. Now you can use OLEDB provider against this database. E.g. using
Visual Basic ADO etc.


------------------------------------------------------------------------
4. Disclaimer (see copying.txt for details)                                    
---------------------------------------------------------------------
                                                                                
This program is free software; you can redistribute it and/or modify            
it under the terms of the GNU General Public License as published by            
the Free Software Foundation; either version 2 of the License, or               
(at your option) any later version.                                             
                                                                                
This program is distributed in the hope that it will be useful,                 
but WITHOUT ANY WARRANTY; without even the implied warranty of                  
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                   
GNU General Public License for more details.                                    
                                                                                
You should have received a copy of the GNU General Public License               
along with this program; if not, write to the Free Software                     
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA


(c) Copyright 2005, St. James Software
All Rights Reserved Worldwide

