#!/usr/bin/env python

import sys
import sre

if len(sys.argv) != 2:
  print "need to supply version as first argument"
  sys.exit()

version = sys.argv[1]
versionparts = [int(part) for part in version.split(".")]
versionparts2 = list(versionparts)[:2] + [0] * (2 - len(versionparts))
versionparts2dot = ".".join([str(part) for part in versionparts2])
versionparts4 = list(versionparts)[:4] + [0] * (4 - len(versionparts))
versionparts4dot = ".".join([str(part) for part in versionparts4])
versionparts4comma = ",".join([str(part) for part in versionparts4])
win32version = "%02d.%02d.%02d%02d" % tuple(versionparts4)
win32commaversion = "%02d,%02d,%02d%02d" % tuple(versionparts4)

print "altering version numbers"
print version
print versionparts
print versionparts4
print versionparts4dot
print versionparts4comma
print win32version
print win32commaversion
sys.stdout.flush()

def dosubst(searchtext, replacetext, filenames):
    searchre = sre.compile(searchtext, sre.M)
    if "\\1" in replacetext:
        replacearg = lambda match: replacetext.replace("\\1", match.group(1))
    else:
        replacearg = replacetext
    sedescape = sre.compile(r'([\(\|\)])')
    for filename in filenames.split():
        origtext = open(filename, "rb").read()
        changedtext = searchre.sub(replacearg, origtext)
        open(filename, "wb").write(changedtext)

dosubst(r'^(version=).*$', r'\1%s' % version, 'Makefile')
dosubst(r'(\bVersion=)"[^"]*"', r'\1"%s"' % versionparts4dot, 'myoledb-debug.wxs myoledb.wxs')
dosubst(r'((FILE|PRODUCT)VERSION) .*$', r'\1 %s' % versionparts4comma, 'myprov.rc')
dosubst(r'(VALUE "(File|Product)Version",) ".*"$', r'\1 "%s\\0"' % win32version, 'myprov.rc')
dosubst(r'(#define VER_(FILE|PRODUCT)VERSION) *[0-9,]*$', r'\1 %s' % win32commaversion, 'myver.h')
dosubst(r'(#define VER_(FILE|PRODUCT)VERSION_STR) *".*"', r'\1 "%s\\0"' % win32version, 'myver.h')
# this handles the MySqlProv OLE DB Provider version
dosubst(r'(MySqlProv)[.][0-9]*[.][0-9]*', r'\1.%s' % versionparts2dot, 'classfac.cpp myoledb.wxs myoledb-debug.wxs')

