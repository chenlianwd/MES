/* Copyright (C) 2000, 2001  SWsoft, Singapore                                  
 *                                                                              
 *  This program is free software; you can redistribute it and/or modify        
 *  it under the terms of the GNU General Public License as published by        
 *  the Free Software Foundation; either version 2 of the License, or           
 *  (at your option) any later version.                                         
 *                                                                              
 *  This program is distributed in the hope that it will be useful,             
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of              
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
 *  GNU General Public License for more details.                                
 *                                                                              
 *  You should have received a copy of the GNU General Public License           
 *  along with this program; if not, write to the Free Software                 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
 */

#ifndef _GUIDS_H_
#define _GUIDS_H_


// MySQL's Data Sources Enumerator
// {C86FB69D-3664-11d2-A112-00104BD15372
DEFINE_GUID(CLSID_MySqlProvEnum, 0xc86fb69d, 0x3664, 0x11d2, 0xa1, 0x12, 0x0, 0x10, 0x4b, 0xd1, 0x53, 0x72);

// MySQL's CLSID
// {C86FB69E-3664-11d2-A112-00104BD15372
DEFINE_GUID(CLSID_MySqlProv, 0xc86fb69e, 0x3664, 0x11d2, 0xa1, 0x12, 0x0, 0x10, 0x4b, 0xd1, 0x53, 0x72);



#endif


