/* Copyright (C) 2000, 2001  SWsoft, Singapore                                  
 *                                                                              
 *  This program is free software; you can redistribute it and/or modify        
 *  it under the terms of the GNU General Public License as published by        
 *  the Free Software Foundation; either version 2 of the License, or           
 *  (at your option) any later version.                                         
 *                                                                              
 *  This program is distributed in the hope that it will be useful,             
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of              
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
 *  GNU General Public License for more details.                                
 *                                                                              
 *  You should have received a copy of the GNU General Public License           
 *  along with this program; if not, write to the Free Software                 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
 */


#ifndef _HEADERS_H_
#define _HEADERS_H_

// STL headers
#include	"stlhelp.h"


//	OLE DB headers
#include	"oledb.h"
#include	"oledberr.h"

// MySQL header files
#include "include/mysql.h"

//	Data conversion library header
#include	"msdadc.h"

// MSDASQL Guids (for conversion library guid)
#include	"msdaguid.h"


#define MT_FAR       far
typedef short int             MT_SINT;
typedef unsigned short        MT_WORD;
typedef int                   MT_INT;
typedef char                  MT_CHAR;
typedef unsigned char         MT_BYTE;
typedef void                  MT_VOID;
typedef long                  MT_LONG;
typedef unsigned long         MT_ULONG;
 typedef size_t MT_SIZE;
typedef MT_CHAR     MT_FAR* MT_CHAR_PTR;
   typedef MT_BYTE     MT_FAR* MT_BUFFER_PTR;
   typedef MT_SINT     MT_FAR* MT_SINT_PTR;
   typedef MT_INT      MT_FAR* MT_INT_PTR;
   typedef MT_WORD     MT_FAR* MT_WORD_PTR;
   typedef MT_LONG     MT_FAR* MT_LONG_PTR;
   typedef MT_ULONG    MT_FAR* MT_ULONG_PTR;
   typedef MT_VOID     MT_FAR* MT_VOID_PTR;
   typedef MT_SIZE     MT_FAR* MT_SIZE_PTR;
#define PHYSICAL_POS_BUF_LEN  4








// Definitions for clearing of fields
#define		START_CLASS()	protected: BYTE __first__;	
#define		FINISH_CLASS()	protected: BYTE __last__;	
#define		CLEAR_CONSTRUCT( className )  \
		memset( &(className::__first__), 0, &(className::__last__) - &(className::__first__) + sizeof(className::__last__) );
#define		COPY_CONSTRUCT( className, from )  \
		memcpy( &(className::__first__), &(from->className::__first__), &(className::__last__) - &(className::__first__) + sizeof(className::__last__) );

// memory allocators overwrites
//#include "allocdbg.h"

//	 Provider - specific general headers
#include	"asserts.h"
#include	"tools.h"
#include	"myprov.h"
#include	"EnumDb.h"
#include	"utilprop.h"

#include	"rc.h"

#include	"bmks.h"

// GUIDs
#include	"guids.h"

// CData object
#include	"data.h"

// CDataSource object and contained interface objects
#include	"datasrc.h"

// CDBSession object and contained interface objects
#include	"dbsess.h"

// CRowset object and contained interface objects
#include	"rowset.h"

// CCommand object and contained interface objects
#include	"command.h"

#endif

