/* Copyright (C) 2000, 2001  SWsoft, Singapore                                  
 *                                                                              
 *  This program is free software; you can redistribute it and/or modify        
 *  it under the terms of the GNU General Public License as published by        
 *  the Free Software Foundation; either version 2 of the License, or           
 *  (at your option) any later version.                                         
 *                                                                              
 *  This program is distributed in the hope that it will be useful,             
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of              
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
 *  GNU General Public License for more details.                                
 *                                                                              
 *  You should have received a copy of the GNU General Public License           
 *  along with this program; if not, write to the Free Software                 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
 */

//	Don't include everything from windows.h, but always bring in OLE 2 support
#define		WIN32_LEAN_AND_MEAN
#define		INC_OLE2

// Basic Windows and OLE everything
#include	<windows.h>
#include	<limits.h>				
#include	<stdio.h>				// vsnprintf, etc.
#include	<stddef.h>				// offsetof, etc.
#include	<wchar.h>				// swprintf
#include	<commdlg.h>			// GetOpenFileName
#include	<olectl.h>
#include	<malloc.h>
#include	<winsock.h>

#pragma warning(disable:4786)

