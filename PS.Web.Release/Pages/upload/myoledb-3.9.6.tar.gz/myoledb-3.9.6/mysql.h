/* Copyright (C) 2000, 2001  SWsoft, Singapore                                  
 *                                                                              
 *  This program is free software; you can redistribute it and/or modify        
 *  it under the terms of the GNU General Public License as published by        
 *  the Free Software Foundation; either version 2 of the License, or           
 *  (at your option) any later version.                                         
 *                                                                              
 *  This program is distributed in the hope that it will be useful,             
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of              
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
 *  GNU General Public License for more details.                                
 *                                                                              
 *  You should have received a copy of the GNU General Public License           
 *  along with this program; if not, write to the Free Software                 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
 */

#pragma once

typedef struct 
{
	SQLCHAR		szName[ 50 ];

	WORD		wOleDbType;
	SQLINTEGER uiLength;
	SQLSMALLINT iDec;
	
	DWORD		dwOffset;

	SQLSMALLINT iNullable;
	LONG		iUpdatable;

	BYTE		bInChangeQuery;
	BOOL		bIsBlob;
	SQLINTEGER	bIsAutoInc;
} MYSQLCOLUMNINFO;

struct SWSTFILEtag;

class CMySql : public CData
{
	START_CLASS(); 

public: // virtual overrides
	// Invalidate buffers
	HRESULT SetMoveInfo( HRESULT hr );
	//@cmember Move relative
	HRESULT MovePending(LONG lRows, BOOL bSaveCurrentPosition );
	//@cmember Move relative
	HRESULT GetFetchedData(LONG lRow, DWORD* pdwBmk);
	//@cmember Move to first row
	HRESULT MoveFirst();
	//@cmember Move to last row
	HRESULT MoveLast();
	//@cmember Move to specified bookmark
	HRESULT MoveBookmark(ULONG* pulBookmark);

	//@cmember Find row from current position
	HRESULT Find(ULONG icol, PCOLUMNDATA pDst/*void* pvValue*/,	DBCOMPAREOP	CompareOp, DBTYPE dbType, bool bForward);

	//@cmember Return the number of rows in the table	
	HRESULT GetRowCnt(DWORD* pdwRows);
	//@cmember Get relative position (by percentage) of the row in table
	HRESULT GetPercentage(ULONG* pulBookmark, double *pdfPPos);
	//@cmember Get bookmark for current row
	HRESULT GetBookmark(ULONG *pulBookmark);
	//@cmember Retrieve number of columns
	HRESULT GetColumnCnt(DWORD* pdwCount);
	//@cmember Retrieve column information
	HRESULT GetColumnInfo(DWORD dwCol, DBCOLUMNINFO* pInfo);
	
	//@cmember Fetch row data
	HRESULT GetRow(ULONG* ulOffset, BYTE* pbProvRow);

	//@cmember Update the current rows values
	HRESULT UpdateRow(ULONG* pulBookmark, ULONG* ulOffset, BYTE* pbProvRow, PACCESSOR	pAccessor, BYTE* pbProvRowOld);
	//@cmember Insert new row
	HRESULT InsertRow(ULONG* ulOffset, BYTE* pbProvRow, PACCESSOR pAccessor);
	//@cmember Remove row with the bmk
	HRESULT DeleteRow(ULONG* pulBookmark);

public:
	CMySql();
	~CMySql();

	//Initialize object and execute query
	HRESULT Init(CDataSource* pDataSrc, LPCOLESTR pszCat, LPCSTR szSQL, DWORD* pdwAffectedRows, ULONG cBindings=0, DBBINDING *pBinding=NULL, void *pData=NULL, int cParamSets=0, ULONG cbRowSize=0);

protected:
	//@cmember Converts  position to bookmark
	inline ULONG Pos2Bmk(ULONG ulPos) { return (ulPos + NUM_OF_RESERVED_BOOKMARKS); }
	//@cmember Converts bookmark to  position  
	inline ULONG Bmk2Pos(ULONG ulBmk) { return (ulBmk - NUM_OF_RESERVED_BOOKMARKS); }
	//@cmember rebind buffers
	HRESULT ReBind(ULONG nRows, ULONG nShift);
	// Allocate a statement to change the recordset
	HRESULT AllocChangeStmt();
	// Apply an OLEDB buffer + accessor to internal buffer
	HRESULT	GetDataFromRow(DWORD dwUseRowInArray, ULONG* ulOffset, BYTE* pbProvRow, PACCESSOR pAccessor, BOOL bOverwriteAutoinc, ULONG ulMaxBind = (ULONG)-1);
	// Set up what fields to be used in SET and WHERE clauses
	void FindIndexFields();
	// Some data types require to be be converted on get
	HRESULT CorrectData(DWORD dwUseRowInArray);

protected:

	class Holder
	{
		CMySql* m_parent;
	public:
		Holder( CMySql* parent );
		DWORD& RowId( DWORD dwRow );
		SQLUSMALLINT& Status( DWORD dwRow );
		SQLUSMALLINT* StatusArray();
		SQLINTEGER& Hint( DWORD dwRow, DWORD dwColumn );
		SQLINTEGER* HintArray( DWORD dwColumn );
		BYTE* RowColumn( DWORD dwRow, DWORD dwColumn );
		HRESULT Realloc( DWORD dwElems );
		BOOL HintIsNull( DWORD dwRow, DWORD dwColumn ) { return Hint( dwRow, dwColumn ) == SQL_NULL_DATA; }

	};
	friend class Holder;

	enum EnumOperations { eNOTDONE, eINSERT, eINSERT_JUSTDONE, eUPDATE, eDELETE };
	enum EnumUseParams { eNONE = 0, eSET = 1, eWHERE = 2, eALL = -1 };

protected:

	DWORD	m_dwCurrentRowInArray;
	DWORD	m_dwValidRowsInArray;
	DWORD	m_dwTotalRowsInArray;
	DWORD	m_dwWasShifted;
	BYTE*	m_myArray;
	
	DWORD	m_dwCurrentRow;	
	DWORD	m_dwRowSize;
	DWORD	m_dwCols;
	DWORD   m_dwRowsInserted;
	MYSQLCOLUMNINFO*	m_pColumnInfo;

	MYSQL_STMT	*m_hstmt;
	MYSQL_STMT	*m_hstmtChange;

	HRESULT		m_hrLastMoveInfo;

	SWSTFILEtag	*m_pUpdateFileInfo;
	EnumOperations	m_enumLastChange;
	CDataSource *pDataSource;
	
	FINISH_CLASS(); 
};

