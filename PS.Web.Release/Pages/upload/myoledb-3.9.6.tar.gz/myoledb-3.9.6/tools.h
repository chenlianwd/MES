/* Copyright (C) 2000, 2001  SWsoft, Singapore                                  
 *                                                                              
 *  This program is free software; you can redistribute it and/or modify        
 *  it under the terms of the GNU General Public License as published by        
 *  the Free Software Foundation; either version 2 of the License, or           
 *  (at your option) any later version.                                         
 *                                                                              
 *  This program is distributed in the hope that it will be useful,             
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of              
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
 *  GNU General Public License for more details.                                
 *                                                                              
 *  You should have received a copy of the GNU General Public License           
 *  along with this program; if not, write to the Free Software                 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
 */

#pragma once

#ifndef sgn
#define sgn(a)	((a>0) ? 1 : ((a<0) ? -1 : 0))
#endif

#ifndef abs
#define abs(a)  ((a>=0) ? a : ((a == MINLONG) ? MAXLONG : -a))
#endif

// max size for characters of a string
#define MAXSTR(sz) (sizeof(sz)/sizeof(*sz)-1)

// strncpy + '\0'
inline char* strcpy0( char* strDst, const char* strSrc, int maxSize )
{ 
	strncpy( strDst, strSrc, maxSize); 
	strDst[ maxSize ] = '\0'; 
	return strDst;
}

inline WCHAR* wcscpy0( WCHAR* strDst, const WCHAR* strSrc, int maxSize )
{ 
	wcsncpy( strDst, strSrc, maxSize); 
	strDst[ maxSize ] = '\0'; 
	return strDst;
}


// simple calls for convertor functions
inline int W2A( const WCHAR* strWide, char* strANSI, int cchANSI )
{
    return WideCharToMultiByte( CP_ACP, 0, strWide, -1, strANSI, cchANSI+1, NULL, NULL );
}

inline int A2W( const char* strANSI, WCHAR* strWide, int cchWide )
{
	return MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, strANSI, -1, strWide, cchWide+1 );
}

// the same for arrays
#define W2Asz( strWide, strANSI ) W2A( strWide, strANSI, MAXSTR(strANSI) )

#define A2Wsz( strANSI, strWide ) A2W( strANSI, strWide, MAXSTR(strWide) )



#ifndef DEBUG

#define INTERFACE_METHOD_START(x)  try {
#define INTERFACE_METHOD_END() } catch(...) { } return E_ABORT; 

#else

struct autoprint{
	LPCSTR m_p;
	autoprint(LPCSTR p) : m_p(p) { TRACE( m_p ); }
	~autoprint() { TRACE("done %s", m_p ); }
};
#define INTERFACE_METHOD_START(x)  autoprint __rosti__(x); try { 
#define INTERFACE_METHOD_END() } catch(...) { TRACE("@@@@@ Exception at %s", __rosti__.m_p ); } return E_ABORT;

#endif